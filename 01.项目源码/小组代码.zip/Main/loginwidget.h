#ifndef LOGINWIDGET_H
#define LOGINWIDGET_H

#include <QWidget>

class LoginWidget : public QWidget
{
    Q_OBJECT
public:
    explicit LoginWidget(QWidget *parent = nullptr);

signals:

};

#endif // LOGINWIDGET_H

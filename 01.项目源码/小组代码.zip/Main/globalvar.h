#ifndef GLOBALVAR_H
#define GLOBALVAR_H

#include <QUrl>
#include <QWidget>

class globalvar
{
    globalvar(QWidget *parent){
    }
public:
    QUrl file_path;
};

#endif // GLOBALVAR_H
